#!/bin/bash

mkdir -p parent/{child1,child2,child3}/{gc1,gc2,gc3}

touch parent/{child1,child2,child3}/{gc1,gc2,gc3}/file


