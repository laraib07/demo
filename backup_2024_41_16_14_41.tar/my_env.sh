#!/bin/bash

export MY_NAME="Laraib"
export MY_AGE="24"
