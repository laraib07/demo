#!/bin/bash

ls loop.sh &> /dev/null

if [ $? -eq 0 ]; then
	echo "Exists"
else
	echo "Doesn't exists"
fi
