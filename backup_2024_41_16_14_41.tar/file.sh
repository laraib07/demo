#!/bin/bash

if [ -f "$1" ]; then
	echo "Regular file"
elif [ -b "$1" ]; then
	echo "block special file"
elif [ -c "$1"]; then
	echo "char special file"
fi
