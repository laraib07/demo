#!/bin/bash

# for ((i = 0; i < 10; ++i))
# do
# 	echo "$i"
# 	if [ $i -gt 5 ]
# 	then
# 		break
# 	fi
# done

i=0
while (( i < 5))
do 
	echo "$i"
	((i++))
done
