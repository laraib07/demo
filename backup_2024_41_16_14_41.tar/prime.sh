#!/bin/bash

read -p "Enter number: " num

sqrt=$(echo "scale=0; sqrt(${num})" | bc -l)


if [ $(echo "$num % 2" | bc) -eq 0 ] && [ $num -ne 2 ] || [ "$num" -eq 1 ]
then
	echo "Not prime"
	exit 1
fi

i=3
while [ $i -le $sqrt ]
do
	if [ $(echo "$num % $i" | bc) -eq 0 ]
	then
		echo "Not prime"
		exit 1
	fi
	i=$(i+2)
done

echo "Prime"

